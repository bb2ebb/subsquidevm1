export * from "./burn.model"
